//: Playground - noun: a place where people can play

import UIKit
import GameplayKit

//randomness technique project
print(arc4random())
print(arc4random())
print(arc4random())
print(arc4random())

//problematic due to modulo bias
print(arc4random() % 6)

//"The Proper Way" -- hindered by the fact that it goes from 0 to number specified
print(arc4random_uniform(6))

//To generate a number using arc4random_uniform in a range, ugly code is required
func RandomInt(min: Int, max: Int) -> Int {
    if max < min { return min }
    return Int(arc4random_uniform(UInt32((max - min) + 1))) + min
}

print(RandomInt(min: 10, max: 20))

//New fancy randoms

//sharedRandoms to follow are used for simple things -- useless for synchronizing network games
//comes with warnings about not guaranteed to be random in certain instances
print(GKRandomSource.sharedRandom().nextInt())

//arc4random replacement
print(GKRandomSource.sharedRandom().nextInt(upperBound: 6))

print(GKRandomSource.sharedRandom().nextBool())

print(GKRandomSource.sharedRandom().nextUniform())

//three options for deterministic randoms
//1. GKLinearCongruentialRandomSource: high performance, lowest randomness
//2. GKMersenneTwisterRandomSource: highest randomness, lowest performance
//3. GKARC4RandomSource: Goldilocks zone

let arc4 = GKARC4RandomSource()
arc4.nextInt(upperBound: 20)

let mersenne = GKMersenneTwisterRandomSource()
mersenne.nextInt(upperBound: 20)

//Apple recommends force flushing ARC4 RNG before using
arc4.dropValues(1024)

//RANDOM DISTRIBUTIONS

//six-sided die
let d6 = GKRandomDistribution.d6()
d6.nextInt()

//twenty-sided die
let d20 = GKRandomDistribution.d20()
d20.nextInt()

//11539-sided die
let crazy = GKRandomDistribution(lowestValue: 1, highestValue: 11539)
crazy.nextInt()

//shuffling distributions avoid clumping of values
let shuffled = GKShuffledDistribution.d6()
print(shuffled.nextInt())
print(shuffled.nextInt())
print(shuffled.nextInt())
print(shuffled.nextInt())
print(shuffled.nextInt())
print(shuffled.nextInt())

//GKGaussianDistribution to create a bell curved random distribution


//Shuffling arrays

//Fisher-Yates array shuffle implemented by Nate Cook
extension Array {
    mutating func shuffle() {
        for i in 0..<(count - 1) {
            let j = Int(arc4random_uniform(UInt32(count - i))) + i
            swapAt(i, j)
        }
    }
}

let lotteryBalls = [Int](1...49)
let shuffledBalls = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: lotteryBalls)
print("Lotto numbers:")
print(shuffledBalls[0])
print(shuffledBalls[1])
print(shuffledBalls[2])
print(shuffledBalls[3])
print(shuffledBalls[4])
print(shuffledBalls[5])

print("Fixed Lotto numbers:")
let fixedLotteryBalls = [Int](1...49)
let fixedShuffledBalls = GKMersenneTwisterRandomSource(seed: 1001).arrayByShufflingObjects(in: fixedLotteryBalls)
for i in 0...5 {
    print(shuffledBalls[i])
}
